from django.apps import AppConfig


class DecodeConfig(AppConfig):
    name = 'Decode'

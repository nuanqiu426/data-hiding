from django.apps import AppConfig


class NlpAnalysisConfig(AppConfig):
    name = 'Nlp_analysis'

from django.apps import AppConfig


class EncodeConfig(AppConfig):
    name = 'Encode'
